
/* script.js */
const WA_NUMBER = '558892708191';
function getCart(){ return JSON.parse(sessionStorage.getItem('JL_CART') || '[]'); }
function saveCart(cart){ sessionStorage.setItem('JL_CART', JSON.stringify(cart)); }
function addToCart(name, price, qtyId){
  let qty = 1;
  if(qtyId){ const el = document.getElementById(qtyId); qty = Number(el ? el.value : 1) || 1; }
  const cart = getCart();
  const idx = cart.findIndex(i=>i.name===name);
  if(idx>-1) cart[idx].qty += qty;
  else cart.push({name, price: Number(price), qty});
  saveCart(cart);
  alert(name + " adicionado ao carrinho ("+qty+")");
}
function removeFromCart(index){
  const cart = getCart();
  cart.splice(index,1);
  saveCart(cart);
  renderCartPage();
}
function changeQty(index, value){
  const cart = getCart();
  const q = Number(value)||0;
  if(q<=0){ removeFromCart(index); return; }
  cart[index].qty = q;
  saveCart(cart);
  renderCartPage();
}
function renderCartPage(){
  const cart = getCart();
  const list = document.getElementById('cart-items');
  const totalEl = document.getElementById('cart-total');
  if(!list) return;
  list.innerHTML='';
  let total=0;
  cart.forEach((it,idx)=>{
    const li = document.createElement('li');
    li.innerHTML = `<strong>${it.name}</strong> - R$ ${it.price.toFixed(2)} x <input type="number" min="1" value="${it.qty}" onchange="changeQty(${idx}, this.value)" style="width:60px"/> <button onclick="removeFromCart(${idx})" style="margin-left:8px">Remover</button> <span style="float:right">R$ ${(it.price*it.qty).toFixed(2)}</span>`;
    list.appendChild(li);
    total += it.price * it.qty;
  });
  totalEl.textContent = total.toFixed(2);
}
function finalizarPedido(){
  const cart = getCart();
  if(cart.length===0){ alert('Seu carrinho está vazio!'); return; }
  const nome = document.getElementById('cliente_nome') ? document.getElementById('cliente_nome').value.trim() : '';
  const telefone = document.getElementById('cliente_tel') ? document.getElementById('cliente_tel').value.trim() : '';
  const endereco = document.getElementById('cliente_endereco') ? document.getElementById('cliente_endereco').value.trim() : '';
  const obs = document.getElementById('cliente_obs') ? document.getElementById('cliente_obs').value.trim() : '';
  if(!nome || !endereco || !telefone){ alert('Por favor preencha Nome, Telefone e Endereço antes de finalizar.'); return; }
  let msg = 'Olá, gostaria de fazer o seguinte pedido:%0A';
  cart.forEach(i=> msg += `- ${i.name} x ${i.qty} (R$ ${(i.price*i.qty).toFixed(2)})%0A` );
  const total = cart.reduce((s,i)=>s + i.price*i.qty,0);
  msg += `%0ATotal: R$ ${total.toFixed(2)}%0A%0A`;
  msg += `Nome: ${encodeURIComponent(nome)}%0ATelefone: ${encodeURIComponent(telefone)}%0AEndereço: ${encodeURIComponent(endereco)}%0AObservações: ${encodeURIComponent(obs)}`;
  window.open(`https://wa.me/${WA_NUMBER}?text=${msg}`,'_blank');
}
document.addEventListener('DOMContentLoaded', ()=>{ renderCartPage(); });
